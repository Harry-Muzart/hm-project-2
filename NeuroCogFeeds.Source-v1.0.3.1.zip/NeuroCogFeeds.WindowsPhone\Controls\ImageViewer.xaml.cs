namespace NeuroCogFeeds.Controls
{
    public sealed partial class ImageViewer : PageBase
    {
    }
}
