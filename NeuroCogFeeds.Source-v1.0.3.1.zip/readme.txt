﻿WINDOWS APP STUDIO. GENERATED CODE README

This folder contains the code for the app you created in Windows App Studio.
It contains projects for Windows 8.1 and Windows Phone 8.1.

To compile this version you will need Visual Studio 2013 Update 4 that you can download from here:
https://go.microsoft.com/fwlink/?LinkId=532495

If you want to publish this app in the store, dont forget to update your privacy terms.

Help and support in the Windows App Studio Forum: 
http://social.msdn.microsoft.com/Forums/wpapps/en-US/home?forum=wpappstudio