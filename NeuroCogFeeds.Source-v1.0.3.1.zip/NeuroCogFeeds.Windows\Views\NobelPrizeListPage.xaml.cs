using NeuroCogFeeds;

namespace NeuroCogFeeds.Views
{
    public sealed partial class NobelPrizeListPage : PageBase
    {
    }
}
