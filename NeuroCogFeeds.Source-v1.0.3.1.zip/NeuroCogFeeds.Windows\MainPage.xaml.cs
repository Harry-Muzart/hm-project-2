namespace NeuroCogFeeds
{
    public sealed partial class MainPage : PageBase
    {
    }
}
